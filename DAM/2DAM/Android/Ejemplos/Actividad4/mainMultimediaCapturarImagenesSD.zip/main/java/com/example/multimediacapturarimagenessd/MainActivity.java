package com.example.multimediacapturarimagenessd;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.FileUtils;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static final int ACTIVITAT_SELECCIONAR_IMATGE = 1;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
    }

    public void accionBoton(View view) {
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, ACTIVITAT_SELECCIONAR_IMATGE);
    }

    //Método que se ejecuta después que el usuario seleccione la foto
    @RequiresApi(api = Build.VERSION_CODES.P)
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        switch (requestCode) {
            case ACTIVITAT_SELECCIONAR_IMATGE:
                if (resultCode == RESULT_OK) {
                    try {
                        //Recogemos el valor de lo que el usuario a seleccionado
                        Uri seleccio = intent.getData();
                        //Lo convertimos a bitmap
                        Bitmap imatge = MediaStore.Images.Media.getBitmap(this.getContentResolver(), seleccio);
                        //Lo escalamos
                        Bitmap reduit = Bitmap.createScaledBitmap(imatge, 540, imatge.getHeight() * 540 / imatge.getWidth(), true);
                        //Pintamos la imágen reducida en el ImageView
                        ImageView imageView = findViewById(R.id.imageView1);
                        imageView.setImageBitmap(reduit);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        }
    }
}