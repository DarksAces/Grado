package com.example.multimediaBarraProgreso;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import com.example.multimediaBarraProgreso.R;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    ProgressBar barraProgreso;
    private MediaObserver observador = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /**********************************************************************************/
        Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.aaa);
        barraProgreso = (ProgressBar) findViewById(R.id.barra_progreso);
        ImageButton boton_play_stop = (ImageButton) findViewById(R.id.boton_play_stop);
        /**********************************************************************************/
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        try {
            mediaPlayer.setDataSource(MainActivity.this, uri);
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaPlayer.start();
        /**********************************************************************************/
        observador = new MediaObserver();
        new Thread(observador).start();
        /**********************************************************************************/
        //Definimos listener del boton para parar / arrancar la música
        boton_play_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                } else {
                    mediaPlayer.start();
                }
            }
        });
        /**********************************************************************************/
        // Se ejecuta cuando acaba la canción
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                observador.stop();
                barraProgreso.setProgress(mp.getCurrentPosition());
                // TODO Auto-generated method stub
                mediaPlayer.stop();
                mediaPlayer.reset();
            }
        });
    }

    //Thread encargado de ir actualizando el progreso
    private class MediaObserver implements Runnable {
        // Se define el stop para poder parar el thread desde la aplicación
        private AtomicBoolean stop = new AtomicBoolean(false);
        public void stop() {
            stop.set(true);
        }
        @Override
        public void run() {
            while (!stop.get()) {
                barraProgreso.setProgress((int)((double)mediaPlayer.getCurrentPosition() / (double)mediaPlayer.getDuration()*100));
                try {
                    Thread.sleep(200);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    //Al cerrar el programa se para
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
    }
}