package com.example.multimediavideointernet;
import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*MediaPlayer mediaPlayer;
        String audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";
        mediaPlayer = MediaPlayer.create(this, Uri.parse(audioUrl));
        mediaPlayer.start();*/

       /* String audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";
        MediaPlayer mediaPlayer;
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        try {
            mediaPlayer.setDataSource(audioUrl);
            mediaPlayer.prepare();

        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaPlayer.start();*/

        WebView myVideoview =findViewById(R.id.WebViewID);
        myVideoview.getSettings().setJavaScriptEnabled(true);
        myVideoview.loadUrl("https://www.youtube.com/watch?v=NUNaXbI-rk4");
        myVideoview.setWebViewClient(new WebViewClient());
        myVideoview.setWebChromeClient(new WebChromeClient());

    }
}