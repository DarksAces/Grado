package com.example.multimediavideointernet;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView myVideoview =findViewById(R.id.WebViewID);
        myVideoview.getSettings().setJavaScriptEnabled(true);
        myVideoview.loadUrl("https://www.youtube.com/watch?v=nk0BIwZP8RM&list=PLknSwrodgQ706MCpRz-_8dVMDoMhfEQ1X");
        myVideoview.setWebViewClient(new WebViewClient());
        myVideoview.setWebChromeClient(new WebChromeClient());
    }
}